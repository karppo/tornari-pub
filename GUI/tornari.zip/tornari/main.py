import os, sys, io, json, math, string, re
#import sqlite3 as sl

from random import randint
import random

from PyQt5.QtWidgets import QWidget,QApplication,QLabel,QLineEdit,QPushButton,QTextEdit,QMenuBar,QAction,QGridLayout,QFileDialog,QMessageBox
#from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEnginePage
from PyQt5.QtGui import *
from PyQt5.QtCore import *


#import configparser
from base64 import b64decode, b64encode
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
from Crypto.Util.Padding import pad

# https://pypi.org/project/pyAesCrypt/
import pyAesCrypt


#from folium.plugins import Draw
#import folium



# sudo pip install PyQt5
# sudo pip install configparser
# sudo pip install pyAesCrypt

# sudo pip install pyinstaller

#sudo pip uninstall crypto
#sudo pip uninstall pycrypto
#sudo pip install pycryptodome


# TODO DISPLAY PASSWORD AS **********
# TODO RESET PASSWORD AFTER N USE

# penis
# MXZ5N0pNaXhvVU9FRHoycQ==;G+j4i1Q8XWPDl/0jtcjgMKWs+50XNchJkA1S7Hacvs15R2pxgkgc86sN5nJNJzWgNgLAHw1uQGwvcqb0HDIgq4AZZktTrE5ph9EUckElxOTm38jrfL2t1QFYQt20UyLSuiPM9vH4ojKPLYtdARkv0vnSxQ+Pl+T973cYDur+iOC4B6nWITu1YW7kbuXG6dOm


class tornariGui(QWidget):
#class tornariGui(QMainWindow):
    def __init__(self,parent=None):
        super().__init__(parent)

        self.resize(1200,500)
        self.move(100,100)
        self.setWindowTitle('Tornari')
        
        self.label_password = QLabel('&Password',self)
        self.lineEdit_password = QLineEdit(self)
        self.label_password.setBuddy(self.lineEdit_password)

        self.btn_decrypt = QPushButton("Decrypt")
        self.btn_decrypt.setToolTip('<b>Decrypt</b> text or files - Drag files or write text to input box. Result is displayed on bottom box.')
        self.btn_encrypt = QPushButton("Encrypt")
        self.btn_encrypt.setToolTip('<b>Encrypt</b> text or files - Drag files or write text to input box. Result is displayed on bottom box.')
        self.btn_clear = QPushButton("Clear")
        self.btn_clear.setToolTip('<b>Clear visible results and inputs </b> ')
        
        self.label_input = QLabel('&Input',self)
        self.textEdit_tekstibox1 = QTextEdit()
        self.label_input.setBuddy(self.textEdit_tekstibox1)
        self.textEdit_tekstibox1.changeEvent

        self.label_output = QLabel('&Output',self)
        self.textEdit_resultbox1 = QTextEdit()
        self.textEdit_resultbox1.changeEvent
        self.label_output.setBuddy(self.textEdit_resultbox1)

        # create menu
        # https://www.tutorialspoint.com/pyqt/qmenubar_qmenu_qaction_widgets.htm
        menubar = QMenuBar()
        actionFile = menubar.addMenu("File")
        #action_new = actionFile.addAction("New")
        #action_new.setShortcut("Ctrl+N")
        action_open = actionFile.addAction("Open")
        action_open.setShortcut("Ctrl+O")
        #action_save = actionFile.addAction("Save")
        #action_save.setShortcut("Ctrl+S")
        #file_child_menu = actionFile.addMenu("parent")
        #file_child_menu.addAction("child1")
        #file_child_menu.addAction("child2")
        #file_child_menu.addAction("child3")
        actionFile.addSeparator()
        
        quit = QAction("Quit",self)
        actionFile.addAction(quit)
        
        #self.close()
        actionEdit  = menubar.addMenu("Edit")
        actionEdit.addAction("TODO clipboard->input")
        actionEdit.addAction("TODO input->clipboard")
        actionEdit.addAction("TODO clipboard->output")
        actionEdit.addAction("TODO output->clipboard")
        actionView  = menubar.addMenu("View")
        #actionView.addAction("Offline Map")
        #actionView.addAction("Map View")
        #actionView.addAction("Dark mode TODO") # TODO DARK MODE
        actionView.addAction("Clear view")
        actionHelp  = menubar.addMenu("Help")
        actionHelp.addAction("Help TODO")
        

        menubar.triggered[QAction].connect(self.process_menubar_actions)

        layout = QGridLayout()
        layout.addWidget(menubar, 0, 0, 1,10)
        layout.addWidget(self.label_password,1,0,1,1)
        layout.addWidget(self.lineEdit_password,1,1,1,9)
        layout.addWidget(self.label_input,2,0,1,1)
        layout.addWidget(self.textEdit_tekstibox1,2,1,1,9)
        layout.addWidget(self.label_output,3,0,1,1)
        layout.addWidget(self.textEdit_resultbox1,3,1,1,9)
        layout.addWidget(self.btn_encrypt,4,1,1,1)
        layout.addWidget(self.btn_decrypt,4,2,1,1)
        layout.addWidget(self.btn_clear,4,3,1,1)
        self.setLayout(layout)


        self.btn_decrypt.clicked.connect(self.click_btn_decrypt)
        self.btn_encrypt.clicked.connect(self.click_btn_encrypt)
        self.btn_clear.clicked.connect(self.click_btn_clear)

        
        # Map window
        self.mapw = None
        self.tmapw = None
        

        #self.tmapw = offlineMapWindow(sys_config=self.config)


    def process_menubar_actions(self, q):
        print(f"'{q.text()}' is triggered")
        
        if q.text() == "Quit":
            self.close()
        elif q.text() == "Open":
            self.open_filepicker()
        elif q.text() == "Clear view":
            self.click_btn_clear()
        
    
    def open_filepicker(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        files, _ = QFileDialog.getOpenFileNames(self,"QFileDialog.getOpenFileNames()", "","All Files (*);;Python Files (*.py)", options=options)
        if files:
            _str = ""
            for _f in files:
                if len(_str) > 0:
                    _str += ";"
                _str += f"file:///{_f}"
            self.textEdit_tekstibox1.setPlainText(_str)
    
    def click_btn_clear(self):
        self.textEdit_tekstibox1.setPlainText("")
        self.textEdit_resultbox1.setPlainText("")

    def click_btn_encrypt(self):
        str_plaintext = self.textEdit_tekstibox1.toPlainText()
        str_password = self.lineEdit_password.text()

        if str_password == "":
            self.warningDialog(severity="warning", title="Password missing", message="Password missing", detail_message="Please set the password.")
            return
        
        
        if str_plaintext.startswith("file:/"):
            if str_plaintext.strip().endswith(".aes"):
                self.warningDialog(severity="warning", title="File already encrypted", message="File already encrypted with AES", detail_message="Given filename is already AES encrypted as the filename ends with '.aes'. Use Decrypt to open the file.")
                return
            
            if ";" in str_plaintext:
                _file_list = str_plaintext.strip().split(";")
            elif "\n" in str_plaintext:
                _file_list = str_plaintext.strip().split("\n")
            else:
                _file_list = [str_plaintext]
            
            if len(str_password) < 32:
                    # TODO config password padding and salt
                    str_password = f"{str_password}"
            #str_password = str_password[0:32]

            try:
                
                _result_str = ""
                for _f in _file_list:
                    if _f.strip() == "":
                        continue
                    _filepath = _f.replace("file:///","").strip()
                    _enc_filepath = f"{_filepath}.aes"
                    
                    pyAesCrypt.encryptFile(_filepath, _enc_filepath, str_password)
                    _result_str += f"{_enc_filepath}\n"

                self.textEdit_resultbox1.setPlainText(f"File/s encrypted as :\n{_result_str}")
            except Exception as e:
                self.textEdit_resultbox1.setPlainText(f"ERROR! {e}")
                print(f"ERROR! Uncatched exception : {e}")

        else:
            if len(str_password) < 32:
                # TODO config password padding and salt
                str_password = f"{str_password}JokuBaddingPurkkaPitaaKeksiaTahanOiskoTassaJo32MerkkiaTaiJotain"

            str_password = str_password[0:32]
            try:
                letters = string.ascii_lowercase
                iv = ''.join(random.choice(letters) for i in range(16))
                #iv = b64decode(iv_base64)
                cipher = AES.new(str_password.encode("utf8"), AES.MODE_CBC, iv.encode("utf8"))
                bytetext = cipher.encrypt(pad(bytes(str_plaintext,'UTF-8'), AES.block_size))
                
                b64iv = b64encode(cipher.iv).decode('utf-8')
                b64text = b64encode(bytetext).decode('utf-8')
                

                self.textEdit_resultbox1.setPlainText(f"{b64iv};{b64text}")

            except ValueError as e:
                self.textEdit_resultbox1.setPlainText(f"ERROR! {e}")
                print(f"ERROR! ValueError : {e}")
            except KeyError as e:
                self.textEdit_resultbox1.setPlainText(f"ERROR! {e}")
                print(f"ERROR! KeyError : {e}")
            except Exception as e:
                self.textEdit_resultbox1.setPlainText(f"ERROR! {e}")
                print(f"ERROR! Uncatched exception : {e}")
            
    
    def click_btn_decrypt(self):
        strAs = self.textEdit_tekstibox1.toPlainText()
        plaintext = "..."
        str_password = self.lineEdit_password.text()

        if str_password == "":
            self.warningDialog(severity="warning", title="Password missing", message="Password missing", detail_message="Please set the password.")
        
        
        
        
        if strAs.startswith("file:/"):
            if not strAs.strip().endswith(".aes"):
                self.warningDialog(severity="warning", title="File not encrypted", message="File is not encrypted with AES", detail_message="Filename doesn't end with '.aes', assuming that it has not been encrypted. Add .aes ending if it has been encryped with AES.")
                return
            if len(str_password) < 32:
                str_password = f"{str_password}"
            #str_password = str_password[0:32]
            if ";" in strAs:
                _file_list = strAs.strip().split(";")
            elif "\n" in strAs:
                _file_list = strAs.strip().split("\n")
            else:
                _file_list = [strAs]
            
            try:
                _result_str = ""
                for _f in _file_list:
                    if _f.strip() == "":
                        continue
                    _filepath = _f.replace("file:///","").strip()
                    _dec_filepath = _filepath.replace(".aes","")
                    
                    pyAesCrypt.decryptFile(_filepath, _dec_filepath, str_password)
                    _result_str += f"{_dec_filepath}\n"

                self.textEdit_resultbox1.setPlainText(f"File/s decrypted as :\n{_result_str}")

            except Exception as e:
                self.textEdit_resultbox1.setPlainText(f"ERROR! {e}")
                print(f"ERROR! Uncatched exception : {e}")
        elif ";" in strAs and "=" in strAs:
            
            if len(str_password) < 32:
                str_password = f"{str_password}JokuBaddingPurkkaPitaaKeksiaTahanOiskoTassaJo32MerkkiaTaiJotain"
            str_password = str_password[0:32]
        
            iv_base64 = strAs.split(";")[0]
            secret_base64 = strAs.split(";")[1]
            strMerkit = ";==;"
            
            
            try:
                #iv = b64decode('V3/oW179L1BRtRP11Nfc/w==')
                iv = b64decode(iv_base64)
                #ciphertext = b64decode('0W6tw7CduTlymN8tOeWAL4UhCuu0ItyV7oZ7q3JWx3k=')
                ciphertext = b64decode(secret_base64)
                #key = b64decode('jbFlVdSLxI7kWkQTTjvoyQ==')
                key = str_password
                ##print(f"pw:{key} --- iv:{iv}")
                cipher = AES.new(key.encode("utf8"), AES.MODE_CBC, iv)
                bytetext = unpad(cipher.decrypt(ciphertext), AES.block_size)
                plaintext = bytetext.decode("utf8")
                ##print(f"Original Message was: {plaintext}")
                self.textEdit_resultbox1.setPlainText(f"{plaintext}")
                
            except ValueError as e:
                self.textEdit_resultbox1.setPlainText(f"ERROR! {e}")
                print(f"ERROR! ValueError : {e}")
            except KeyError as e:
                self.textEdit_resultbox1.setPlainText(f"ERROR! {e}")
                print(f"ERROR! KeyError : {e}")
            except Exception as e:
                self.textEdit_resultbox1.setPlainText(f"ERROR! {e}")
                print(f"ERROR! Uncatched exception : {e}")
        else:
            strMerkit = "????"
            self.textEdit_resultbox1.setPlainText(f"{strMerkit} : {plaintext}")

    def closeEvent(self, event):
        reply = QMessageBox.question(self, 'Quit', 'Are you sure you want to quit?',
        QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            event.accept()
            if self.mapw is not None:
                self.mapw.close()
            if self.tmapw is not None:
                self.tmapw.close()
        else:
            event.ignore()
    
    def warningDialog(self, severity="warning", title="warning", message="Lorem ipsum", detail_message=""):
        msg = QMessageBox()
        if severity == "information":
            msg.setIcon(QMessageBox.Information)
        elif severity == "warning":
           msg.setIcon(QMessageBox.Warning)
        else:
            msg.setIcon(QMessageBox.Critical)
        msg.setIcon(QMessageBox.Warning)
        msg.setInformativeText(message)
        msg.setWindowTitle(title)
        msg.setDetailedText(detail_message)
        msg.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
        msg.buttonClicked.connect(self.msgbtn)
            
        ##retval = msg.exec_()
        ##print(f"value of pressed message box button: {retval}")

    def msgbtn(self, i):
        ##print(f"Button pressed is: {i.text()}")
        pass

if __name__ == '__main__':
    #config = configparser.ConfigParser()
    #config.read('tornari.conf')
    app = QApplication(sys.argv)
    win = tornariGui()
    win.show()
    sys.exit(app.exec_())