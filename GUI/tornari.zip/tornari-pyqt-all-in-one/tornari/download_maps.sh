#!/bin/bash

# https://kartat.kapsi.fi/#Maastokarttarasteri
mkdir -p ./maps/maastokarttarasteri_500k_jhs180/kaikki
rsync -arPv tiedostot.kartat.kapsi.fi::mml/maastokarttarasteri_500k_jhs180/kaikki ./maps/maastokarttarasteri_500k_jhs180/

mkdir -p ./maps/maastokarttarasteri_250k_jhs180/kaikki
rsync -arPv tiedostot.kartat.kapsi.fi::mml/maastokarttarasteri_250k_jhs180/kaikki ./maps/maastokarttarasteri_250k_jhs180/

mkdir -p ./maps/maastokarttarasteri_100k_jhs180/kaikki
rsync -arPv tiedostot.kartat.kapsi.fi::mml/maastokarttarasteri_100k_jhs180/kaikki ./maps/maastokarttarasteri_100k_jhs180/

mkdir -p ./maps/maastokarttarasteri_50k_jhs180/painovari
rsync -arPv tiedostot.kartat.kapsi.fi::mml/maastokarttarasteri_50k_jhs180/painovari ./maps/maastokarttarasteri_50k_jhs180/
